source ./launch-job.sh < <(echo 'convert
socofing_optimized
resnet50
convjob
False
')
