source ./launch-job.sh < <(echo "train
socofing_optimized
resnet50
trainjob
False
")
